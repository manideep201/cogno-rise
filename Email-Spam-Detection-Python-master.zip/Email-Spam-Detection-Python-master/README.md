# Email-Spam-Detection-Python
This is a tutorial post to show how can we build a email spam detection system from scratch using Python
